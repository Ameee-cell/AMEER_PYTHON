a=input("enter the number")
b=input("enter the number")
c=input("enter the number")
if a>b and a>c:
        print("a is greater")
elif b>c and b>a:
         print("b is greater")
elif c>a and c>b:
         print("c is greater")
else:print("all are same")