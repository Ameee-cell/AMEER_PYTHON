a=int(input("enter the name of number"))
print(a)
if a%2==0:
  print("even")
else:
  print("odd")