a=int(input("enter the number"))
temp=a
sum=0
while temp!=0:
    d=temp%10
    sum=(sum*10)+d
    temp=temp//10
if sum==a:
    print("It is  a palindrome number")
else:
    print("It is not a palindrome number")