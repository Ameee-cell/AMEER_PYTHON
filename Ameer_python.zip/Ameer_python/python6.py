a="rohit"
b="sharma"
print(a,b)
c=a
a=b
b=c
print(a,b)